﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eLandoProgram
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int L = 1000;
            bool[] flag = new bool[L + 1];
            for (int i = 4; i <= L; i += 2)
            {
                flag[i] = true;
            }
            for (int i = 3; i * i <= L; i += 2)
            {
                if (!flag[i])
                {
                    for (int j = 2 * i; j <= L; j += i)
                    {
                        flag[j] = true;
                    }
                }
            }
            
            int N = 5;
            int N1 = int.Parse(Console.ReadLine());
            N = N1;
            int[] pr = new int[N];
            int br = 0;
            for (int i = 2; i <= L && br<N; i++)
            {
                if (!flag[i])
                {
                    pr[br++] = i;
                }
            }
            int [,] output = new int[N,N];
            for(int i = 0; i < N; i++)
            {
                for(int j = 0; j < N; j++)
                {
                    output[i, j] = pr[i] * pr[j];
                }
            }
            Console.Write("{0,7}", " ");
            for (int i = 0; i < N; i++)
            {
                Console.Write("{0,7:D}",pr[i]);
            }
            Console.WriteLine();
            for (int i = 0; i < N; i++)
            {
                Console.Write("{0,7:D}", pr[i]);
                for(int j=0; j < N; j++)
                    {
                        Console.Write("{0,7:D}",output[i,j]);
                }
                Console.WriteLine();
            }
        }
    }
}
